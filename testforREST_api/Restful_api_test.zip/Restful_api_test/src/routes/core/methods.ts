export enum HTTP_METHODS {
    GET,
    POST,
    UPDATE,
    DELETE
}
