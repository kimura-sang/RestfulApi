export const environment = {
    port: 8080,
    mongoURL: 'mongodb://localhost/test'
};