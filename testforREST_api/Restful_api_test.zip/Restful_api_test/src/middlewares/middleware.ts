export abstract class Middleware {
    public static canActivate(req, res, next): void { }
}